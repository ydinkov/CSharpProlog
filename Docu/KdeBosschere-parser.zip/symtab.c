/*
 * Toy symbol table
 */
#include "symtab.h"
#include <stdio.h>

void *malloc(size_t);


symboltype *symtab[HASHSIZE];

void initsymtab()
{
  int i;
  
  for (i=0; i<HASHSIZE; i++)
    symtab[i] = (symboltype *)NULL;
}

int computeKey(char *atom){
  int x;
  char *str;
  x = 0;
  str = atom;
  while (*str != 0) {
    x += *str; str++;
  }
  return x;
}

/*
symboltype* hashProcedure(char *name, int arity, procedureAddress module, int entry){
  symboltype *pred;
  pred = findsymbol(name, arity);
  if (pred->extra) printf("function already define\n");
  else {
#ifdef GCCJUMP
    pred->extra = module;
#else
    pred->extra = (continuationtype *)malloc(sizeof(continuationtype));
    pred->extra->proca = module;
    pred->extra->entry = entry;
#endif
  }
}
*/

symboltype *findsymbol(char *s, int n)
{
  int i;
  symboltype *p, *q = (symboltype *)NULL;
  int r= 1;

  i = (computeKey(s) + n) % HASHSIZE;
  p = symtab[i];
  while (p && r) {
    r = strcmp(p->name, s);
        /* we assume that two functors with different arity belong to a
           different bucket in the hashtable */
    if (r < 0) {
      q = p;
      p = p->next;
    } else if ( r > 0) {
      p = (symboltype *)NULL;
    }
  }
  if (!r) return p; /* symbol found */

  p = (symboltype *)malloc(sizeof(symboltype)); /* create symbol */
  p->name = (char *)malloc(strlen(s)+1);
  strcpy(p->name, s);
  p->arity = n;
  p->extra = NULL;
  if (q) {
    p->next = q->next;
    q->next = p;
  }
  else {
    p->next = symtab[i];
    symtab[i] = p;
  }
  return p;
}


void showsymtab()
{
  int i;

  for (i=0; i<HASHSIZE; i++)
    if (symtab[i]) {
        symboltype *p = symtab[i];
        printf("[%3d]: ", i);
        while (p) {
          printf("%s/%d ", p->name, p->arity);
          p = p->next;
        }
        puts("");
      }
}



