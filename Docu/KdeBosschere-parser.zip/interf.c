#include <stdio.h>
#include "interf.h"
/*
 * interface module with the standard Prolog parser
 *
 */

extern heapcell heap[];

termtype errorterm = {__ERRORTAG, {0}};

termtype makefloat(double f)
/*
 * internatizes the float value f
 * and return it 
 */
{
  termtype tp;
  tp.tag = __FLOATTAG;
  __FLOAT(tp) = f;
  return tp;
}

termtype makeinteger(int i)
/*
 * internalizes the integer value i
 * and return it
 */
{
  termtype tp;
  tp.tag = __INTTAG;
  tp.u.i = i;
  return tp;
}

termtype makeatom(char *s)
/*
 * internalizes the string s and returns
 * it as atom 
 */
{
  termtype tp;
  tp.tag = __ATOMTAG;
  __ATOM(tp) = getsymbol(s, 0);
  return tp;
}

termtype maketerm(char *s,int n)
/*
 * internalizes the functor string s with arity n
 * and returns a pointer to it
 */
{
  termtype tp;
  tp.tag = __TERMTAG;
  tp.u.heapvalue = H;
  H->tag = 0;
  __ATOM(*H) = getsymbol(s, n);
  H += (n+1);
  return tp;
}

termtype makelist(termtype Arg1, termtype Arg2) {
  termtype tp;
  tp.tag = __TERMTAG;
  tp.u.heapvalue = H;
  H-> tag = 0;
  __ATOM(*H) = getsymbol(".", 2);
  *(H+1) = Arg1;
  *(H+2) = Arg2;
  H +=3;
  return tp;
}

termtype makevar()
/*
 * creates a variable and returns it
 */
{
  termtype tp;
  tp.tag = __VARTAG;
  tp.u.heapvalue = H;
  H->tag = __VARTAG;
  H->u.heapvalue = (termtype *)NULL;
  H++;
  return tp;
}


symboltype *getsymbol(s,a)
char *s;
int a;
/*
 * return the internalized version of the functor s with
 * arity a; create the symbol if it does not already exist
 */
{
  return (symboltype *)findsymbol(s,a);
}

termtype *deref(termtype *tp)
/* no comment */
{
  while (ISVAR(*tp) && tp->u.heapvalue) tp = tp->u.heapvalue;
  return (termtype *)tp;
}

int fileread(register char *buf, register int len)
/* 
 * read at most len bytes from stdin into buf
 * returns the number of bytes read 
 */
{
   return read(0, buf, len);
}

int operator(char *op, int *prepri, int *inpri, int *postpri, int *spec)
/*
 * operator interface.
 * given a string representation op,
 * it returns the priority as prefix operator (prepri),
 * infix operator (inpri) and postfix operator (postpri).
 * In addition it returns the specifier of the operator.
 * This is the OR of all the possible (overloaded)
 * specifiers. The function returns 1 is op is an 
 * operator, 0 otherwise 
 */
{
  return findoperator(op, prepri, inpri, postpri, spec);
}

void putvarname(register char *buffer, register termtype *t)
/*
 * this functions writes a null terminated string
 * in buffer, corresponding to the output format
 * for variable t
 */
{
  sprintf(buffer, "_%d", (heapcell)t-(heapcell)heap);
}

void showheap (heapcell From, heapcell To)
{
   heapcell H;
   H = From;
   while (!(H == To)){
   if ISFLOAT(*H)     printf("%i: FLOAT %f\n", H, __FLOAT(*H));
   else if ISINT(*H)  printf("%i: INTEGER %i\n", H, __INT(*H)); 
   else if ISATOM(*H) printf("%i: ATOM %s\n", H, __ATOMNAME(*H));
   else if ISTERM(*H) printf("%i: TERM %i\n",H, H->u.heapvalue);
   else if ISVAR(*H)  printf("%i: VAR %i\n", H, H->u.heapvalue);
   else if (H->tag == 0)  
                      printf("%i: FUNC  %s %i\n", H, 
			     H->u.atom->name, H->u.atom->arity);
   else if (H->tag == __ERRORTAG) printf("error\n");
   H++;
 }
 
}
