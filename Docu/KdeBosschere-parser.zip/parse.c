#include <stdlib.h>
#include <stdio.h>
#include "token.h"
#include "interf.h"

termtype heap[10000];
heapcell H;

void main(argc, argv)
int argc;
char **argv;
{
   termtype *H1;
   termtype tp;

   initsymtab();
   initoperators();
   inittokenizer();
   predefinedoperators();
   allocatefilebuffer(stdin,"user_input");
   H1 = heap;
   while (H=heap, tp = readterm(stdin), tp.tag != __ERRORTAG) {
/*     showheap(H1, H);
*/     if (ISATOM(tp) && !strcmp(__ATOMNAME(tp), "end_of_file")) exit(0);
     if (writeterm(stdout,&tp,1+4) == 5) printf(" ");
     puts(".");
   }
   returnfilebuffer(stdin);
}
