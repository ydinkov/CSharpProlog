#define HASHSIZE  10000


typedef struct symboltype {
  int arity;
  char *name;
  void *extra;
  struct symboltype *next;
} symboltype;


void initsymtab();
void showsymtab();
symboltype *findsymbol();
