Important note:

These programs are from the book:

Natural Language Processing for Prolog Programmers
Michael A. Covington
Englewood Cliffs, NJ: Prentice-Hall
ISBN 0-13-629213-5

First edition (copyright 1994), released August 2, 1993.

The programs on this disk are documented in that book.  We cannot
undertake to assist people who are attempting to use the programs
without the book.

The file 'errors.txt' contains a list of errors known to appear in the
printed edition.  They will be corrected in subsequent printings.

At present, answers to the exercises are not distributed.  However,
any instructor who would like assistance is welcome to contact the
author.


